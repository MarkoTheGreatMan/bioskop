export class Msg {
  message: string = "";
}
