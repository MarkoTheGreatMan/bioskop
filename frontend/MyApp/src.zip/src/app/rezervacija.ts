export class Rezervacija{
  ulogovaniKorisnik: string = "";
  nazivFilma: string = "";
  cenaKarte: number = 0;
  termin?: Date;
  status: string = ""
}
