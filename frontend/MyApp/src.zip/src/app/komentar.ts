export class Komentar{
  username: string = ""
  film: String = ""
  ocena: number = 0;
  komentar: string = ""
}
